#include "OpenGLTest.h"

OpenGLTest::OpenGLTest(QWidget *parent)
    : QWidget(parent)
{
    ui.setupUi(this);
}
