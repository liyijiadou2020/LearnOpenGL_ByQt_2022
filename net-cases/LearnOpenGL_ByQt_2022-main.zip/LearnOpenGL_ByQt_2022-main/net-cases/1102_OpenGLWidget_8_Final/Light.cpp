#include "Light.h"

Light::Light()
	: QObject()
{
}

Light::~Light()
{
}
