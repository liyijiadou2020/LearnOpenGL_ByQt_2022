#include "Cone.h"

Cone::Cone()
{    

}

Cone::~Cone()
{
}


void Cone::init()
{
}

void Cone::update()
{
}

void Cone::paint()
{
}
